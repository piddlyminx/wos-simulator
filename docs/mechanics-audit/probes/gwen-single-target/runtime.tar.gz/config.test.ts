import assert from "node:assert/strict";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";

import {
  loadSimulatorConfig,
  loadSimulatorConfigFromDir,
} from "./config-node";
import type { SkillFile } from "./types";

test("loadSimulatorConfig accepts keyed nested effects on a type-less attack carrier", () => {
  const root = writeConfigWithTroopEffect({
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    duration: { attacks: { count: 1 } },
    trigger_effects: {
      child: {
        type: "active.hero.lethality.up",
        value: 10,
        units: { applies_to: "parent.use.source", applies_vs: "parent.use.target" }
      }
    }
  }, { type: "attack", every: 2, source: "infantry" });

  const config = loadSimulatorConfigFromDir(root);
  assert.equal(config.diagnostics.unsupportedEffects.length, 0);
});

test("loadSimulatorConfig rejects attack-relative selectors on direct turn effects", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { applies_to: "trigger.source", applies_vs: "target" }
  }, { type: "turn" });

  assert.throws(() => loadSimulatorConfigFromDir(root), /turn effect cannot use attack\/use-relative selector/i);
});

test("loadSimulatorConfig rejects source and target on turn triggers", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { applies_to: "self.infantry" }
  }, { type: "turn", source: "infantry" });
  assert.throws(() => loadSimulatorConfigFromDir(root), /turn trigger cannot define source or target/i);
});

test("loadSimulatorConfig rejects legacy fields in simulator config", () => {
  const root = join(tmpdir(), `wos-simulator-config-${Date.now()}`);
  mkdirSync(join(root, "hero_definitions"), { recursive: true });
  writeFileSync(join(root, "hero_generation_stats.json"), JSON.stringify({
    S1: { attack: 1, defense: 1, lethality: 1, health: 1, legacy: true }
  }));
  writeFileSync(join(root, "troop_skills.json"), JSON.stringify({ name: "Troop Skills", skills: {} }));
  writeFileSync(join(root, "hero_definitions", "Example.json"), JSON.stringify({ name: "Example", hero_generation: "S1", skills: {} }));

  assert.throws(() => loadSimulatorConfigFromDir(root), /legacy field/i);
});

test("loadSimulatorConfig rejects legacy effect metadata fields without naming them in source", () => {
  const legacyEffectMetadataKey = ["effect", "op"].join("_");
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { applies_to: "trigger.source", applies_vs: "target" },
    [legacyEffectMetadataKey]: 101
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /legacy field/i);
});

test("loadSimulatorConfig rejects legacy duration shape", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { applies_to: "trigger.source", applies_vs: "target" },
    duration: { type: "attack", value: 1 } as never
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /duration key type.*not supported/i);
});

test("simulator config source does not reference legacy effect metadata names", () => {
  const legacyEffectMetadataKey = ["effect", "op"].join("_");
  const source = readFileSync(fileURLToPath(new URL("./config.ts", import.meta.url)), "utf8");

  assert.equal(source.includes(legacyEffectMetadataKey), false);
});

test("loadSimulatorConfig rejects duplicate normalized hero aliases", () => {
  const root = join(tmpdir(), `wos-simulator-config-alias-${Date.now()}`);
  mkdirSync(join(root, "hero_definitions"), { recursive: true });
  writeFileSync(join(root, "hero_generation_stats.json"), JSON.stringify({ S1: { attack: 1, defense: 1, lethality: 1, health: 1 } }));
  writeFileSync(join(root, "troop_skills.json"), JSON.stringify({ name: "Troop Skills", skills: {} }));
  writeFileSync(join(root, "hero_definitions", "Alpha.json"), JSON.stringify({ name: "Same Hero", hero_generation: "S1", skills: {} }));
  writeFileSync(join(root, "hero_definitions", "Beta.json"), JSON.stringify({ name: "Same-Hero", hero_generation: "S1", skills: {} }));

  assert.throws(() => loadSimulatorConfigFromDir(root), /duplicate hero alias.*samehero/i);
});

test("loadSimulatorConfig rejects legacy trigger units filters", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { applies_to: "trigger.source", applies_vs: "target" }
  });
  const troopSkills = JSON.parse(readFileSync(join(root, "troop_skills.json"), "utf8")) as SkillFile;
  troopSkills.skills.ExampleSkill.trigger = { type: "attack", units: { side: "enemy", applies_vs: ["infantry"] } } as never;
  writeFileSync(join(root, "troop_skills.json"), JSON.stringify(troopSkills));

  assert.throws(() => loadSimulatorConfigFromDir(root), /legacy trigger units/i);
});

test('loadSimulatorConfig rejects native effect applies_vs "all"', () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { applies_to: "trigger.source", applies_vs: "all" }
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /applies_vs.*all/i);
});

test("loadSimulatorConfig rejects native effect units.side", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.lethality.up",
    value: 10,
    units: { side: "enemy", applies_to: "target" }
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /units\.side/i);
});

test("loadSimulatorConfig rejects trigger-relative effect selectors on battle_start triggers", () => {
  const root = writeConfigWithTroopEffect(
    {
      type: "active.hero.lethality.up",
      value: 10,
      units: { applies_to: "trigger" }
    },
    { type: "battle_start" }
  );

  assert.throws(() => loadSimulatorConfigFromDir(root), /battle_start.*trigger-relative.*applies_to.*trigger/i);
});

test("loadSimulatorConfig rejects negative native bucket effect values", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.attack.down",
    value: -10,
    units: { applies_to: "trigger.source", applies_vs: "target" }
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /negative.*active\.hero\.attack\.down.*value/i);
});

test("loadSimulatorConfig rejects invalid attack_order unit names", () => {
  const root = writeConfigWithTroopEffect({
    type: "attack_order",
    value: ["marksman", "invalid-unit", "lancer"],
    units: { applies_to: "lancer", applies_vs: "marksman" }
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /attack_order.*unsupported unit.*invalid-unit/i);
});

test("loadSimulatorConfig rejects effects targeting static buckets unless they are fully static", () => {
  const turnRoot = writeConfigWithTroopEffect({
    type: "passive.attack.up",
    value: 10
  });
  const durationRoot = writeConfigWithTroopEffect(
    {
      type: "passive.attack.up",
      value: 10,
      duration: { turns: { count: 1 } }
    },
    { type: "pre_battle" }
  );
  const evolvingRoot = writeConfigWithTroopEffect(
    {
      type: "passive.attack.up",
      value: 10,
      value_evolution: { type: "fixed_decay", step: "round", value: 1 }
    },
    { type: "pre_battle" }
  );
  const emptyDurationRoot = writeConfigWithTroopEffect(
    {
      type: "passive.attack.up",
      value: 10,
      duration: {}
    },
    { type: "pre_battle" }
  );
  const probabilityRoot = writeConfigWithTroopEffect(
    {
      type: "passive.attack.up",
      value: 10
    },
    { type: "pre_battle", probability: 50 }
  );
  const maxStackingRoot = writeConfigWithTroopEffect(
    {
      type: "passive.attack.up",
      value: 10,
      same_effect_stacking: "max"
    },
    { type: "pre_battle" }
  );
  const battleStartRoot = writeConfigWithTroopEffect(
    {
      type: "passive.attack.up",
      value: 10
    },
    { type: "battle_start" }
  );
  const runtimeEffectRoot = writeConfigWithTroopEffect(
    {
      type: "active.hero.attack.up",
      value: 10
    },
    { type: "pre_battle" }
  );

  assert.throws(() => loadSimulatorConfigFromDir(turnRoot), /static bucket passive\.attack\.up.*pre_battle/i);
  assert.throws(() => loadSimulatorConfigFromDir(durationRoot), /static bucket passive\.attack\.up.*duration/i);
  assert.throws(() => loadSimulatorConfigFromDir(emptyDurationRoot), /static bucket passive\.attack\.up.*duration/i);
  assert.throws(() => loadSimulatorConfigFromDir(evolvingRoot), /static bucket passive\.attack\.up.*value_evolution/i);
  assert.throws(() => loadSimulatorConfigFromDir(probabilityRoot), /pre_battle skill.*probability/i);
  assert.throws(() => loadSimulatorConfigFromDir(maxStackingRoot), /static bucket passive\.attack\.up.*cannot use max stacking/i);
  assert.throws(() => loadSimulatorConfigFromDir(battleStartRoot), /static bucket passive\.attack\.up.*pre_battle/i);
  assert.throws(() => loadSimulatorConfigFromDir(runtimeEffectRoot), /pre_battle skill may only contain static passive-bucket effects/i);
});

test("loadSimulatorConfig rejects skill effects targeting input-derived static buckets", () => {
  const playerRoot = writeConfigWithTroopEffect(
    { type: "player.attack", value: 10 },
    { type: "battle_start" }
  );
  const troopsRoot = writeConfigWithTroopEffect(
    { type: "troops.baseAttack", value: 10 },
    { type: "battle_start" }
  );

  assert.throws(() => loadSimulatorConfigFromDir(playerRoot), /input-derived static bucket/i);
  assert.throws(() => loadSimulatorConfigFromDir(troopsRoot), /input-derived static bucket/i);
});

test("loadSimulatorConfig rejects invalid trigger_damage_jobs selector strings", () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "effect.applies_v" }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /invalid trigger_damage_jobs target selector.*effect\.applies_v/i);
});

test("loadSimulatorConfig rejects stacking metadata on extra skill attacks", () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    same_effect_stacking: "max",
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target" }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /extra_skill_attack does not support same_effect_stacking/i);
});

test("loadSimulatorConfig rejects trigger_damage_jobs with typoed keys", () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ soruce: "use.source", target: "effect.applies_vs" }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /unknown trigger_damage_jobs key soruce/i);
});

test("loadSimulatorConfig rejects per-job extra skill damage multipliers", () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target", multiplier: 50 }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /unknown trigger_damage_jobs key multiplier/i);
});

test("loadSimulatorConfig accepts explicit damage kinds and rejects removed delay metadata or the removed extra kind", () => {
  const validNormal = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target", damage_kind: "normal" }]
  });
  const removedDelay = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target", delivery_delay_turns: 1 }]
  });
  const removedExtraKind = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target", damage_kind: "extra" }]
  });

  assert.doesNotThrow(() => loadSimulatorConfigFromDir(validNormal));
  assert.throws(() => loadSimulatorConfigFromDir(removedDelay), /unknown trigger_damage_jobs key delivery_delay_turns/i);
  assert.throws(() => loadSimulatorConfigFromDir(removedExtraKind), /damage_kind.*normal.*skill/i);
});

test("loadSimulatorConfig accepts modifier damage-kind applicability and rejects invalid uses", () => {
  const valid = writeConfigWithTroopEffect({
    type: "active.hero.damageTaken.up",
    applies_to_damage_kinds: ["normal"],
    value: 25
  });
  const validBoth = writeConfigWithTroopEffect({
    type: "type.normal.damageTaken.up",
    applies_to_damage_kinds: ["normal", "skill"],
    value: 25
  });
  const invalidKind = writeConfigWithTroopEffect({
    type: "active.hero.damageTaken.up",
    applies_to_damage_kinds: ["mystery"] as never,
    value: 25
  });
  const empty = writeConfigWithTroopEffect({
    type: "active.hero.damageTaken.up",
    applies_to_damage_kinds: [],
    value: 25
  });
  const duplicate = writeConfigWithTroopEffect({
    type: "active.hero.damageTaken.up",
    applies_to_damage_kinds: ["normal", "normal"],
    value: 25
  });
  const ambiguousOldName = writeConfigWithTroopEffect({
    type: "active.hero.damageTaken.up",
    damage_kind: "normal",
    value: 25
  } as never);
  const replacedSingularName = writeConfigWithTroopEffect({
    type: "active.hero.damageTaken.up",
    applies_to_damage_kind: "normal",
    value: 25
  } as never);
  const nonModifier = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    applies_to_damage_kinds: ["normal"],
    value: 100,
    trigger_damage_jobs: [{ source: "use.source", target: "use.target" }]
  });

  assert.doesNotThrow(() => loadSimulatorConfigFromDir(valid));
  assert.doesNotThrow(() => loadSimulatorConfigFromDir(validBoth));
  assert.throws(() => loadSimulatorConfigFromDir(invalidKind), /applies_to_damage_kinds.*normal.*skill/i);
  assert.throws(() => loadSimulatorConfigFromDir(empty), /applies_to_damage_kinds.*non-empty array/i);
  assert.throws(() => loadSimulatorConfigFromDir(duplicate), /applies_to_damage_kinds.*duplicates/i);
  assert.throws(
    () => loadSimulatorConfigFromDir(ambiguousOldName),
    /damage_kind is ambiguous.*applies_to_damage_kinds.*trigger_damage_jobs\[\]\.damage_kind/i
  );
  assert.throws(
    () => loadSimulatorConfigFromDir(replacedSingularName),
    /applies_to_damage_kind was replaced by applies_to_damage_kinds/i
  );
  assert.throws(
    () => loadSimulatorConfigFromDir(nonModifier),
    /applies_to_damage_kinds is only supported for runtime damage modifiers/i
  );
});

test("loadSimulatorConfig reports the removed extra_attack effect type as unsupported", () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target", damage_kind: "normal" }]
  });

  const config = loadSimulatorConfigFromDir(root);
  assert.equal(config.diagnostics.unsupportedEffects.some((effect) => effect.type === "extra_attack"), true);
});

test("loadSimulatorConfig rejects per-job skill reporting overrides", () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source", target: "use.target", reports_skill_kills: false } as never]
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /unknown trigger_damage_jobs key reports_skill_kills/i);
});

test("loadSimulatorConfig requires trigger_damage_jobs source and target", () => {
  const missingSourceRoot = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ target: "effect.applies_vs" }]
  });
  const missingTargetRoot = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "trigger.target" },
    trigger_damage_jobs: [{ source: "use.source" }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(missingSourceRoot), /requires source/i);
  assert.throws(() => loadSimulatorConfigFromDir(missingTargetRoot), /requires target/i);
});

test('loadSimulatorConfig rejects effect.applies_vs jobs gated by applies_vs "any"', () => {
  const root = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "any" },
    trigger_damage_jobs: [{ source: "use.source", target: "effect.applies_vs" }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /effect\.applies_vs.*applies_vs.*any/i);
});

test("loadSimulatorConfig rejects effect.applies_vs jobs without concrete applies_vs", () => {
  const omittedRoot = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source" },
    trigger_damage_jobs: [{ source: "use.source", target: "effect.applies_vs" }]
  });
  const allRoot = writeConfigWithTroopEffect({
    type: "extra_skill_attack",
    value: 100,
    units: { applies_to: "trigger.source", applies_vs: "all" },
    trigger_damage_jobs: [{ source: "use.source", target: "effect.applies_vs" }]
  });

  assert.throws(() => loadSimulatorConfigFromDir(omittedRoot), /effect\.applies_vs.*concrete applies_vs/i);
  assert.throws(() => loadSimulatorConfigFromDir(allRoot), /applies_vs.*all/i);
});

test("loadSimulatorConfig accepts the deferred shield value formula schema", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value: 30,
    value_formula: { type: "percent_of", source: "trigger.total_kills" },
    units: { applies_to: "trigger.source", applies_vs: "enemy.any" },
    duration: { turns: { delay: 1, count: 1 } },
    same_effect_stacking: "max"
  }, { type: "attack", source: "infantry" });

  assert.doesNotThrow(() => loadSimulatorConfigFromDir(root));

  const sourceAttackRoot = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value: 30,
    value_formula: { type: "percent_of", source: "trigger.source_attack" },
    units: { applies_to: "trigger.source", applies_vs: "enemy.any" },
    duration: { turns: { delay: 1, count: 1 } },
    same_effect_stacking: "max"
  }, { type: "attack", source: "infantry" });

  assert.doesNotThrow(() => loadSimulatorConfigFromDir(sourceAttackRoot));
});

test("loadSimulatorConfig rejects malformed or non-attack value formulas", () => {
  const badSource = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value: 30,
    value_formula: { type: "percent_of", source: "trigger.damage" }
  }, { type: "attack", source: "infantry" });
  const typoedKey = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value: 30,
    value_formula: { type: "percent_of", source: "trigger.total_kills", scale: 2 }
  }, { type: "attack", source: "infantry" });
  const wrongTrigger = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value: 30,
    value_formula: { type: "percent_of", source: "trigger.total_kills" }
  }, { type: "turn" });
  const evolving = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value: 30,
    value_formula: { type: "percent_of", source: "trigger.total_kills" },
    value_evolution: { type: "fixed_decay", step: "turn", value: 1 }
  }, { type: "attack", source: "infantry" });
  const missingCoefficient = writeConfigWithTroopEffect({
    type: "active.hero.shield",
    value_formula: { type: "percent_of", source: "trigger.total_kills" }
  }, { type: "attack", source: "infantry" });

  assert.throws(() => loadSimulatorConfigFromDir(badSource), /invalid value_formula source.*trigger\.damage/i);
  assert.throws(() => loadSimulatorConfigFromDir(typoedKey), /unknown value_formula key scale/i);
  assert.throws(() => loadSimulatorConfigFromDir(wrongTrigger), /value_formula requires an attack trigger/i);
  assert.throws(() => loadSimulatorConfigFromDir(evolving), /cannot combine value_formula with value_evolution/i);
  assert.throws(() => loadSimulatorConfigFromDir(missingCoefficient), /requires a numeric percentage coefficient/i);
});

test("loadSimulatorConfig rejects missing required effects", () => {
  const root = writeConfigWithTroopEffect({
    type: "active.troop.damageTaken.down",
    value: 10,
    requires_effect: "MissingShield/1",
    units: { applies_to: ["infantry"], applies_vs: "any" }
  });

  assert.throws(() => loadSimulatorConfigFromDir(root), /requires_effect references missing effect MissingShield\/1/i);
});

function writeConfigWithTroopEffect(effect: Record<string, unknown>, trigger: Record<string, unknown> = { type: "attack" }): string {
  const root = join(tmpdir(), `wos-simulator-config-trigger-jobs-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  mkdirSync(join(root, "hero_definitions"), { recursive: true });
  writeFileSync(join(root, "hero_generation_stats.json"), JSON.stringify({ S1: { attack: 1, defense: 1, lethality: 1, health: 1 } }));
  writeFileSync(
    join(root, "troop_skills.json"),
    JSON.stringify({
      name: "Troop Skills",
      skills: {
        ExampleSkill: {
          trigger,
          effects: { "ExampleSkill/1": effect }
        }
      }
    })
  );
  return root;
}
